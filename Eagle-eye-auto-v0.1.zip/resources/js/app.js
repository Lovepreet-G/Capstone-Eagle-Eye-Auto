import './bootstrap';

import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
