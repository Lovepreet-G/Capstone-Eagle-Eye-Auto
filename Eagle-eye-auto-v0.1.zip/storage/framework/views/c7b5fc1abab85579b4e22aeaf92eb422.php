

<?php $__env->startSection("content"); ?>
<div id="intro">
    <div id="intro-left">
        <span id="intro-brand">
            Eagle Eye Auto
        </span>
        <span>
            <small style="font">// A Garage For All Make And Models</small>
        </span>
        <big>
            Advanced Vehicle <br>Repair Service
        </big>
    </div>
    

</div>
<div id="second-section">
    <div id="maintenance">
        <span>Maintenance Services</span>
        <p>Providing top-quality maintenance and repair services to keep your vehicle running smoothly and efficiently</p>                 
    </div>
    <div id="engine-bg">
        
    </div>
    <div id="certified">
        <span>Certified Repair Services</span>
        <p>Offering certified repair services to ensure your vehicle receives expert care and attention.</p>        
    </div>
    <div id="oil">
        
    </div>
</div>
<div id="services-section">
    <div class="heading" >
        Get Over 100 car repairs
    </div>
    <div id="services">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div >
                <div id="icon">
                    <img src="<?php echo e(asset($service->service_icon)); ?>" alt="<?php echo e($service->service_name); ?>">
                </div>
                <span><?php echo e($service->service_name); ?></span>
                <div><?php echo e($service->service_description); ?></div>
            </div>            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        

    </div>
    <a href="<?php echo e(route('services')); ?>" class="btn btn-primary mt-4">View All Services</a>
</div>

    <div id="reviews" class="d-flex flex-column align-items-center">
        <div class="heading">
            Tell Us How We are Doing
        </div>
        <div class="d-flex w-100 justify-content-around">
            <div id="post-review" class="d-flex flex-column">
                <h5>Post a Review</h5>
                <form id="review-form" action="<?php echo e(route('reviewsstore')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" id="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="rating" class="form-label">Rate Us (1-10)</label>
                        <input type="number" name="rating" class="form-control" id="rating" min="1" max="10" required>
                    </div>
                    <div class="mb-3">
                        <label for="review_description" class="form-label">Review Description</label>
                        <textarea name="review_description" class="form-control" id="review_description" rows="3" required></textarea>
                    </div>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success mt-4">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                
            </div>
            <div id="show-review" class="d-flex flex-column">
                <h5>Voices of Our Customer</h5>
                <!-- Example review cards -->
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3" style="width: 18rem; margin-bottom: 10px;">
                        <div class="card-body">
                            <h5 class="card-title"><span class="initial-circle" style="background-color: #<?php echo e(substr(md5($review->name), 0, 6)); ?>;"> <?php echo e(strtoupper(substr($review->name, 0, 1))); ?></span>&nbsp;<?php echo e($review->name); ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted">Rating: <?php echo e($review->rating); ?>/10</h6>
                            <p class="card-text"><?php echo e($review->review_description); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\http5225\Capstone-Eagle-Eye-Auto\resources\views/homepage.blade.php ENDPATH**/ ?>