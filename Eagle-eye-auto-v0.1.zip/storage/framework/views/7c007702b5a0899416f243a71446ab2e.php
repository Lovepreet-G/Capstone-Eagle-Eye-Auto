

<?php $__env->startSection("content"); ?>
<div id="services-section">
    <div class="heading" >
        All Services
    </div>
    <div id="services">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div >
                <div id="icon">
                    <img src="<?php echo e(asset($service->service_icon)); ?>" alt="<?php echo e($service->service_name); ?>">
                </div>
                <span><?php echo e($service->service_name); ?></span>
                <div><?php echo e($service->service_description); ?></div>
            </div>            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\http5225\Capstone-Eagle-Eye-Auto\resources\views/allServices.blade.php ENDPATH**/ ?>