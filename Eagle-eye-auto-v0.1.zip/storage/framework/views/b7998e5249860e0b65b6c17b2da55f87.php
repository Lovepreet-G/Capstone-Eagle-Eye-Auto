

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Edit Service</h2>
    <form method="POST" action="<?php echo e(route('admin.updateService', ['service' => $service->id])); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="service_name" class="form-label">Service Name</label>
            <input type="text" class="form-control" id="service_name" name="service_name" value="<?php echo e(old('service_name', $service->service_name)); ?>">
        </div>
        <div class="mb-3">
            <label for="service_description" class="form-label">Service Description</label>
            <textarea class="form-control" id="service_description" name="service_description" rows="3"><?php echo e(old('service_description', $service->service_description)); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="service_icon" class="form-label">Service Icon</label>
            <input type="file" class="form-control" id="service_icon" name="service_icon">
            <?php if($service->service_icon): ?>
            <img src="<?php echo e(asset($service->service_icon)); ?>" alt="<?php echo e($service->service_name); ?>" style="max-width: 80px; max-height: 80px;">
            <?php else: ?>
            <p>No icon uploaded.</p>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary">Update Service</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\http5225\Capstone-Eagle-Eye-Auto\resources\views/admin/editService.blade.php ENDPATH**/ ?>