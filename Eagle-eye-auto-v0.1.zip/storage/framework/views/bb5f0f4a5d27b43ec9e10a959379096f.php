

<?php $__env->startSection('content'); ?>
    <h1>Admin Dashboard</h1>    
    
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4">
                <a href="<?php echo e(route('admin.employees')); ?>" class="card-link">
                    <div class="card card-box bg-red">
                        <div class="inner">
                            <h3><?php echo e($activeEmployeesCount); ?></h3>
                            <p>Total Employees</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-users"></i>
                        </div>
                    </div>
                </a>
            </div>
    
            <div class="col-lg-3 col-md-6 mb-4">
                <a href="<?php echo e(route('admin.carRepairHistory')); ?>" class="card-link">
                    <div class="card card-box bg-blue">
                        <div class="inner">
                            <h3>$<?php echo e(number_format($salesThisMonth, 2)); ?></h3>
                            <p>Sales This Month</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-money"></i>
                        </div>
                    </div>
                </a>
            </div>
    
            <div class="col-lg-3 col-md-6 mb-4">
                <a href="<?php echo e(route('admin.carRepairHistory')); ?>" class="card-link">
                    <div class="card card-box bg-orange">
                        <div class="inner">
                            <h3><?php echo e($carsRepairedThisMonth); ?></h3>
                            <p>Cars Repaired This Month</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-car"></i>
                        </div>
                    </div>
                </a>
            </div>
    
            
        </div>
    </div>
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\http5225\Capstone-Eagle-Eye-Auto\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>