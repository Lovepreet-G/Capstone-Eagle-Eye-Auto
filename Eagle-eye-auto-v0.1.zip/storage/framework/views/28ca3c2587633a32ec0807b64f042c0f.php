


<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Manage Services</h2>
    <a href="<?php echo e(route('admin.addService')); ?>" class="btn btn-primary mb-3">Add New Service</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Service Name</th>
                <th>Service Description</th>
                <th>Service Icon</th>
                <th scope="col">Actions</th> 
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($service->id); ?></td>
                <td><?php echo e($service->service_name); ?></td>
                <td><?php echo e($service->service_description); ?></td>
                <td><img src="<?php echo e(asset($service->service_icon)); ?>" alt="<?php echo e($service->service_name); ?>" width="30"></td>
                <td>
                    <a href="<?php echo e(route('admin.editService', ['service' => $service->id])); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <button onclick="deleteService(<?php echo e($service->id); ?>)" class="btn btn-danger">Delete</button>
                    <form id="delete-form-<?php echo e($service->id); ?>" action="<?php echo e(route('admin.destroyService', $service->id)); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
   function deleteService(serviceId) {
        if (confirm('Are you sure you want to delete this service?')) {
            document.getElementById('delete-form-' + serviceId).submit();
        }
    }
      
</script>
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\http5225\Capstone-Eagle-Eye-Auto\resources\views/admin/services.blade.php ENDPATH**/ ?>