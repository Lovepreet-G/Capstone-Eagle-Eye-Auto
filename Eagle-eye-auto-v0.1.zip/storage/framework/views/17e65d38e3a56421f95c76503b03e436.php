


<?php $__env->startSection('content'); ?>

<div id="reviews" class="d-flex flex-column align-items-center">
    <div class="heading mb-4">
        What Our Customers Say :)
    </div>
    
    <div class="w-75 mt-5">
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3" style="width: 18rem; margin-bottom: 10px;">
                <div class="card-body">
                    <h5 class="card-title"><span class="initial-circle" style="background-color: #<?php echo e(substr(md5($review->name), 0, 6)); ?>;"><?php echo e(strtoupper(substr($review->name, 0, 1))); ?></span><?php echo e($review->name); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted">Rating: <?php echo e($review->rating); ?>/10</h6>
                    <p class="card-text"><?php echo e($review->review_description); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="heading mb-4">
        Tell Us How We are Doing
    </div>
    <div class="w-50">
        <form action="<?php echo e(route('reviewsstore')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" id="name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" id="email" required>
            </div>
            <div class="mb-3">
                <label for="rating" class="form-label">Rate Us (1-10)</label>
                <input type="number" name="rating" class="form-control" id="rating" min="1" max="10" required>
            </div>
            <div class="mb-3">
                <label for="review_description" class="form-label">Review Description</label>
                <textarea name="review_description" class="form-control" id="review_description" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    <?php if(session('success')): ?>
        <div class="alert alert-success mt-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\http5225\Capstone-Eagle-Eye-Auto\resources\views/allReviews.blade.php ENDPATH**/ ?>