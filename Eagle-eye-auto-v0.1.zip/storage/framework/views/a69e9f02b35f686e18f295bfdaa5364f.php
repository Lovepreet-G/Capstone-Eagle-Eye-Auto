<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1>Add New Employee</h1>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.employeeStore')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="employee_name" class="form-label">Employee Name</label>
                <input type="text" class="form-control" id="employee_name" name="employee_name" autocomplete="given-name" required>
            </div>
            <div class="mb-3">
                <label for="email_address" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email_address" name="email_address" autocomplete="email" required>
                <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
            </div>
            <div class="mb-3">
                <label for="mobile_number" class="form-label">Mobile Number</label>
                <input type="text" class="form-control" id="mobile_number" name="mobile_number" autocomplete="tel" required>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address</label>
                <input type="text" class="form-control" id="address" name="address"  autocomplete="address"required>
            </div>
            <div class="mb-3">
                <label for="job_role" class="form-label">Job Role</label>
                <select class="form-control" id="job_role" name="job_role" required>
                    <option value="">Select Job Role</option>
                    <option value="Manager">Manager</option>
                    <option value="Sales Executive">Sales Executive</option>
                    <option value="Mechanic">Mechanic</option>
                    <option value="Lead Mechanic">Lead Mechanic</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="joining_date" class="form-label">Joining Date</label>
                <input type="date" class="form-control" id="joining_date" name="joining_date" required>
            </div>
            <div class="mb-3">
                <label for="resignation_date" class="form-label">Resignation Date (Optional)</label>
                <input type="date" class="form-control" id="resignation_date" name="resignation_date">
            </div>
            <button type="submit" class="btn btn-primary">Add Employee</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\http5225\Capstone-Eagle-Eye-Auto\resources\views/admin/addEmployee.blade.php ENDPATH**/ ?>