<?php $__env->startSection('content'); ?>
    <h1>List of Employees</h1>
    <form method="GET" action="<?php echo e(route('admin.employees-search')); ?>" class="mb-3">
        <div class="input-group">
            <input type="text" id="search" name="search" class="form-control" placeholder="Search" value="<?php echo e(request()->get('search')); ?>">
            <div class="input-group-prepend">
                <label class="input-group-text" for="field">Search by:</label>
                <select class="form-select" name="field">
                    <option value="employee_name" <?php echo e(request()->get('field') == 'employee_name' ? 'selected' : ''); ?>>Name</option>
                    <option value="mobile" <?php echo e(request()->get('field') == 'mobile' ? 'selected' : ''); ?>>Mobile</option>
                    <option value="email" <?php echo e(request()->get('field') == 'email' ? 'selected' : ''); ?>>Email</option>
                    <option value="address" <?php echo e(request()->get('field') == 'address' ? 'selected' : ''); ?>>Address</option>
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Search</button>
        </div>
    </form>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Mobile</th>
                <th scope="col">Address</th>
                <th scope="col">Job Role</th>
                <th scope="col">Joining Date</th>
                <th scope="col">Resignation Date</th>
                <th scope="col">Action</th> 
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($employee->id); ?></th>
                    <td><?php echo e($employee->employee_name); ?></td>
                    <td><?php echo e($employee->email); ?></td>
                    <td><?php echo e($employee->mobile); ?></td>
                    <td><?php echo e($employee->address); ?></td>
                    <td><?php echo e($employee->job_role); ?></td>
                    <td><?php echo e($employee->joining_date); ?></td>
                    <td><?php echo e($employee->resignation_date); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.editEmployee', $employee->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\http5225\Capstone-Eagle-Eye-Auto\resources\views/admin/employees.blade.php ENDPATH**/ ?>