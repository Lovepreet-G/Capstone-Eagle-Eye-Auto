<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2>Car Repair History</h2>
        <form method="GET" action="<?php echo e(route('admin.carRepairHistorySearch')); ?>" class="mb-3">
            <div class="input-group">
                
                <input type="text" name="search" class="form-control" placeholder="Search" value="<?php echo e(request()->get('search')); ?>">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="field">Search by:</label>
                    <select class="form-select" name="field" id="field">
                        <option value="vin" <?php echo e(request()->get('field') == 'vin' ? 'selected' : ''); ?>>VIN</option>
                        <option value="repair_type" <?php echo e(request()->get('field') == 'repair_type' ? 'selected' : ''); ?>>Repair Type</option>
                        <option value="parts_used" <?php echo e(request()->get('field') == 'parts_used' ? 'selected' : ''); ?>>Parts Used</option>
                    </select>
                </div>
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </form>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Car Registration Number</th>
                    <th scope="col">Repair Date</th>
                    <th scope="col">Repair Type</th>
                    <th scope="col">Parts Used</th>
                    <th scope="col">Total Cost</th>
                    <th scope="col">Employee Name</th>
                    <th scope="col">Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $carRepairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($repair->id); ?></th>
                        <td><?php echo e($repair->vin); ?></td>
                        <td><?php echo e($repair->repair_date); ?></td>
                        <td><?php echo e($repair->repair_type); ?></td>
                        <td><?php echo e($repair->parts_used); ?></td>
                        <td><?php echo e($repair->total_cost); ?></td>
                        <td><?php echo e($repair->employee ? $repair->employee->employee_name : 'N/A'); ?></td>
                        <td><?php echo e($repair->note); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\http5225\Capstone-Eagle-Eye-Auto\resources\views/admin/carRepairHistory.blade.php ENDPATH**/ ?>